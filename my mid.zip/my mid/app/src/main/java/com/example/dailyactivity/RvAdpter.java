package com.example.dailyactivity;

import android.content.Context;
import android.graphics.ColorSpace;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RvAdpter extends RecyclerView.Adapter<RvAdpter.ViewHolder> {
    ArrayList<ModelcClass> Items;
    public RvAdpter(Context context, ArrayList<ModelcClass>name){
        Items=name;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_name,tv_time;
        ImageView iv_Proirty;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Items=new ArrayList<>();
            tv_name=itemView.findViewById(R.id.tv_task);
            iv_Proirty=itemView.findViewById(R.id.iv_prority);
            tv_time=itemView.findViewById(R.id.tv_time);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.task_recycleview,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tv_name.setText(Items.get(position).getName());
        holder.tv_time.setText(Items.get(position).getTime());
        switch (Items.get(position).getPriority()) {
            case "high":
                holder.iv_Proirty.setImageResource(R.drawable.green);
                break;
            case "low":
                holder.iv_Proirty.setImageResource(R.drawable.red);
                break;
            case "Medium":
                holder.iv_Proirty.setImageResource(R.drawable.yellow);
                break;

    }
    }

    @Override
    public int getItemCount() {
        return Items.size();
    }
}
