package com.example.dailyactivity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.ArrayList;
import java.util.Calendar;

public class AddItem extends AppCompatActivity implements RecycleAdpter.clicked {
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager manager;
    RecyclerView.Adapter myAdpter;
    EditText Name ,Date,Time;
    CheckBox cb_medium,cb_low,cb_heigh;
    TextView empty;
    Button btn_save;
    ImageView iv_cancel,iv_add,iv_calander,iv_clock,iv_repeat,iv_empty;
    ArrayList<String>item=new ArrayList<String >();
    String Priority="";
    String name,time,date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        init();
        iv_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder=new AlertDialog.Builder(AddItem.this);
                View view=getLayoutInflater().inflate(R.layout.custom_diaog,null);
                final EditText et_name=(EditText)view.findViewById(R.id.et_name);
                Button btn_cancel=(Button)view.findViewById(R.id.btn_cancel);
                Button btn_ok=(Button)view.findViewById(R.id.btn_ok);
                builder.setView(view);
                final AlertDialog alertDialog=builder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                btn_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
                btn_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name=et_name.getText().toString();
                        alertDialog.dismiss();
                        item.add(name);
                        if (!item.isEmpty()) {
                            recyclerView.setVisibility(View.VISIBLE);
                            iv_empty.setVisibility(View.INVISIBLE);
                            empty.setVisibility(View.INVISIBLE);
                        }
                        myAdpter.notifyDataSetChanged();
                    }
                });
                alertDialog.show();
            }
        });
        manager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        myAdpter=new RecycleAdpter(this,item);
        recyclerView.setAdapter(myAdpter);
        cb_heigh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cb_heigh.isChecked())
                {
                    cb_low.setChecked(false);
                    cb_medium.setChecked(false);
                }
            }
        });
        cb_low.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cb_low.isChecked())
                {
                    cb_heigh.setChecked(false);
                    cb_medium.setChecked(false);
                }
            }
        });
        cb_medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cb_medium.isChecked())
                {
                    cb_heigh.setChecked(false);
                    cb_low.setChecked(false);
                }
            }
        });
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cb_heigh.isChecked())
                {
                    Priority="high";
                }
                else if(cb_low.isChecked())
                {
                    Priority="low";
                }
                else if(cb_medium.isChecked())
                {
                    Priority="medium";
                }
                Intent intent=new Intent();
                name=Name.getText().toString();
                time=Time.getText().toString();
                date=Date.getText().toString();
                intent.putExtra("Name",name);
                intent.putExtra("Time", time);
                intent.putExtra("Date", date);
                intent.putExtra("Priority", Priority);
                setResult(RESULT_OK,intent);
                finish();
            }
        });
        iv_clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimeDiloa(Time);
            }
        });
        iv_calander.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateDialog(Date);
            }
        });


    }

    private void showTimeDiloa(EditText time) {
        Calendar calendar=Calendar.getInstance();
        TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                calendar.set(Calendar.MINUTE,minute);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("HH:mm");
                time.setText(simpleDateFormat.format(calendar.getTime()));
            }
        };
        new TimePickerDialog(AddItem.this,timeSetListener,
                calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
    }

    private void showDateDialog(final EditText date) {
              Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd");
                date.setText(simpleDateFormat.format(calendar.getTime()));
            }
        };
        new DatePickerDialog(AddItem.this,dateSetListener,calendar.get(Calendar.YEAR)
                ,calendar.get(calendar.MONTH),calendar.get(calendar.DAY_OF_MONTH)).show();
    }

    private void init() {
        Name=findViewById(R.id.etName);
        Date=findViewById(R.id.et_Date);
        Time=findViewById(R.id.et_Time);
        empty=findViewById(R.id.tv_empty);
        iv_cancel=findViewById(R.id.iv_cancel);
        iv_add=findViewById(R.id.iv_add);
        iv_calander=findViewById(R.id.iv_calander);
        iv_clock=findViewById(R.id.iv_clock);
        iv_empty=findViewById(R.id.iv_empty);
        iv_repeat=findViewById(R.id.iv_repeat);
        btn_save=findViewById(R.id.btn_Save);
        recyclerView=findViewById(R.id.rv_item);
        cb_heigh=findViewById(R.id.ck_Heigh);
        cb_low=findViewById(R.id.ck_Low);
        cb_medium=findViewById(R.id.ck_Medium);
        recyclerView.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onClicked(int index) {
        item.remove(index);
        myAdpter.notifyDataSetChanged();
    }
}