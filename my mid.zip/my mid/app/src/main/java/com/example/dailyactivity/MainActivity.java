package com.example.dailyactivity;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager manager;
    RecyclerView.Adapter myAdpter;
    FloatingActionButton btn_Add;
    TextView tv_empty;
    EditText et_date;
    ImageView iv_Empty,iv_Edit;
    final int Edit_Profile=1;
    ArrayList<ModelcClass>items;
    String Name,Priority;
    String Time,Date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        items=new ArrayList<>();
        init();
        btn_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,AddItem.class);
                startActivityForResult(intent,Edit_Profile);
                recyclerView.setVisibility(View.VISIBLE);
                tv_empty.setVisibility(View.INVISIBLE);
                iv_Empty.setVisibility(View.INVISIBLE);

            }
        });
        manager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        myAdpter=new RvAdpter(this,items);
        recyclerView.setAdapter(myAdpter);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Edit_Profile) {
            if (resultCode == RESULT_OK) {
                Name = data.getStringExtra("Name");
                Time = data.getStringExtra("Time");
                Date = data.getStringExtra("Date");
                Priority = data.getStringExtra("Priority");
                items.add(new ModelcClass(Name,Priority,Date,Time));
                myAdpter.notifyDataSetChanged();
            }
            else if (resultCode == RESULT_CANCELED)
            {
                finish();
            }
        }
    }

    private void init() {
        et_date=findViewById(R.id.et_date);
        iv_Edit=findViewById(R.id.iv_Edit);
        iv_Empty=findViewById(R.id.iv_empty);
        tv_empty=findViewById(R.id.tv_empty);
        btn_Add=findViewById(R.id.btn_Add);
        recyclerView=findViewById(R.id.rv_task);
        recyclerView.setVisibility(View.INVISIBLE);
    }
}