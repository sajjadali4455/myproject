package com.example.dailyactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleAdpter extends RecyclerView.Adapter<RecycleAdpter.ViewHolder> {
    ArrayList<String> Names=new ArrayList<>();
    clicked myclick;
    public interface clicked
    {
        public void onClicked(int index);
    }
    public RecycleAdpter(Context context,ArrayList<String>name){
        Names=name;
        myclick=(clicked) context;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_name;
        ImageView iv_delete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_name=itemView.findViewById(R.id.tv_itemName);
            iv_delete=itemView.findViewById(R.id.ic_delete);
            iv_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myclick.onClicked(Names.indexOf(itemView.getTag()));
                }
            });
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycleview,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.itemView.setTag(Names.get(position));
        holder.tv_name.setText(Names.get(position));
    }

    @Override
    public int getItemCount() {
        return Names.size();
    }
}
