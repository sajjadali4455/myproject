package com.example.dailyactivity;

import java.util.ArrayList;

public class ModelcClass {

        private String Name;
        private String Priority;
        private String Date;
        private String Time;


        public ModelcClass() {
        }


    public ModelcClass(String name, String priority, String date, String time) {
            Name = name;
            Priority = priority;
            Date = date;
            Time = time;

        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }

        public String getPriority() {
            return Priority;
        }

        public void setPriority(String priority) {
            Priority = priority;
        }

        public String getDate() {
            return Date;
        }

        public void setDate(String date) {
            Date = date;
        }

        public String getTime() {
            return Time;
        }

        public void setTime(String time) {
            Time = time;
        }


}
